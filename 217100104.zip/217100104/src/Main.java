import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        double grossSalary = 125000, hour_rate = 1000, net_Salary, hrs_worked, deductions;

        String empName;
        String empType;

        System.out.println ("Enter employee's name");

        empName = in.nextLine();

        System.out.println ("Enter Employee type M (Monthly), W (Weekly), H (Hourly)");

        empType = in.nextLine();

        if (empType.equals("M") || empType.equals("m")){

            deductions = ((grossSalary * 3)/100) + ((grossSalary * 30)/100);

            net_Salary = grossSalary - deductions;

            System.out.println("Employee Names : " + empName);
            System.out.println("\nEmployee type : Monthly");
            System.out.println("\nNet Salary : " + net_Salary);


        }else if (empType.equals("W") || empType.equals("w")){

            deductions = ((grossSalary * 3)/100);

            net_Salary = grossSalary - deductions;

            System.out.println("Employee Names : " + empName);
            System.out.println("\nEmployee type : Weekly");
            System.out.println("\nNet Salary : " + net_Salary);

        }else{

            System.out.println ("Number of hours worked per week");

            hrs_worked = Double.parseDouble(in.nextLine());

            net_Salary = hour_rate * hrs_worked;

            System.out.println("Employee Names : " + empName);
            System.out.println("\nEmployee type : Hourly" );
            System.out.println("\nNet Salary : " + net_Salary);

        }

    }
}
